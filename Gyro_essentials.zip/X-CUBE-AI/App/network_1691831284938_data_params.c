/**
  ******************************************************************************
  * @file    network_1691831284938_data_params.c
  * @author  AST Embedded Analytics Research Platform
  * @date    Sat Aug 12 14:45:51 2023
  * @brief   AI Tool Automatic Code Generator for Embedded NN computing
  ******************************************************************************
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */

#include "network_1691831284938_data_params.h"


/**  Activations Section  ****************************************************/
ai_handle g_network_1691831284938_activations_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(NULL),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};




/**  Weights Section  ********************************************************/
AI_ALIGNED(32)
const ai_u64 s_network_1691831284938_weights_array_u64[193] = {
  0xc0865752c0633872U, 0x3ff0d9edb986316cU, 0xbf21044d3d1d4519U, 0x3ff40b30402dfc13U,
  0x3fde58f2bd5251a8U, 0xbf264bdc3fd1f451U, 0x3f48411ec0199f47U, 0x40c6b424beae9724U,
  0x3dd509debe992b57U, 0xbfb5f8d43f4e62baU, 0xbfc1323a3f125646U, 0x3f0c815a3fa15041U,
  0x3f330edc3f28fb62U, 0x3f3a23103e0aea66U, 0xbf1a1157bf85b0aeU, 0xc00fdc11c01679fcU,
  0xc0b827ef3bcfcfcbU, 0xc03ce6d13e0f2d7eU, 0x3e3f37c3c0a79cf4U, 0x3f8bc59a3f44d8feU,
  0xbffa8ba2bfe4cba3U, 0x3f9351f13f45b0acU, 0xbeae183b3e794af2U, 0x3fa6b16c3dba005eU,
  0xbd168ec1be370ffeU, 0xbe05de7d3e874352U, 0xbe9d38f5bed1270cU, 0xbebf19a6bee6a76aU,
  0xbf94e31d3f038f25U, 0xbcb9251abe30057eU, 0xbf5cd4233ede7646U, 0x3f27ccaabe1ed25bU,
  0x3f1d55433e94fe0fU, 0xbf139e5fc0687497U, 0x3f4e12983e5ce901U, 0x3e28fccbbf6d8d80U,
  0xbf673b4dbf6f1b95U, 0x3fceaa99bee3a733U, 0xbfd52d39be4878e5U, 0x3f83ce4e3ca87c23U,
  0x40086119bf946200U, 0xbec3f9203f2ab36fU, 0x3f1218813d7035f5U, 0xbc6829ce3f1e90aeU,
  0x3e82ca8f3e9209f9U, 0xbf0b760ebed11a38U, 0x3d64acc03eee8a69U, 0x3f1605de3f89028dU,
  0xbf7309943ef5dfafU, 0x3fef4a2cbe0d6040U, 0xbd870770c1242245U, 0xbeabcecc3f2dd52cU,
  0xbf220ac53f15c0deU, 0x3f6f67493eb438feU, 0x3f0b45c93ee379d4U, 0xbf00ecedc011b514U,
  0xbe862a9ec03634a3U, 0xbf3957b9bc6d3beaU, 0x3f39995bc0184e85U, 0xbfb9b42abfc1e280U,
  0x3f20cdb3bf3b46c3U, 0xbe2cb2aebf1ac851U, 0xbef9ca403ee39dcaU, 0xbe368ce03eac98ffU,
  0x3d8ffc61bebe4054U, 0xbf0a2ab6becac6dfU, 0xc0993df7bfb86e2fU, 0xbed6490dbee6b378U,
  0x400251783eac96c9U, 0xbe217b59bf3017c1U, 0x3f9986653f94405dU, 0xbeef75a13ff0a1e3U,
  0x3fb5ec8c3e237810U, 0xbe8049c53ff9f08cU, 0xbeca9b8f3f4cf182U, 0x3ebe3bdfbe1af581U,
  0x3f21dd50c0350b45U, 0xbe90b01bbde7aaecU, 0xbb23210f3fc8409bU, 0xbebafe6fbf042741U,
  0xbe1e6de73f714973U, 0xbea208ee3ffa2029U, 0xbe8197c2bde2a538U, 0x3f10f124bfdcac79U,
  0x3e16413bbd70be0eU, 0xbf5113ff3e026d2eU, 0x3f76ee893e81ddbbU, 0x3f029d42bcd56582U,
  0x3f3750a03fbd38c9U, 0xbf85c7813e97aadeU, 0x3f244606bee005a6U, 0xbece4dfabef36686U,
  0x3e5219433ee32ffeU, 0x3f91ea923f9e2967U, 0xbf15fe72bfffe0b3U, 0x3e8d361bbdcf9d86U,
  0x3e57c9613efae369U, 0xc112654c3eca1064U, 0xbfafab203fb9cf48U, 0x3d76f4aa3eb5f510U,
  0xbf17f70ebee58444U, 0x3f480b063fcee284U, 0xbf41fd37bf070b88U, 0x3e050e973fdbedf2U,
  0x3f864aaa3edaf296U, 0xbf791e8c3e99e6cfU, 0xbfd51294bcee5e1cU, 0xbf01d293befd142bU,
  0xbf4c0e2d40262313U, 0x3e38e200be435ad2U, 0x3e4162373eee1b3eU, 0xbf821fd7be917176U,
  0xbeed9c88bf2fbaf7U, 0xbee82474c00b3a31U, 0x3e82c4163fcaa97bU, 0x3f9fc9fac00c9bdcU,
  0xc04d5e4ebe228ffbU, 0xbdff7c3bbeab68d5U, 0xbf88da3d3eae48b4U, 0xbf3c40c7bf127699U,
  0xbfc34c7b3f28f6c3U, 0xbf0139b7bf0ad158U, 0x3e833b7dbef3cc49U, 0xbd158debbda4d4fdU,
  0x3d60370bbe9e92fbU, 0xbec3f905befc91c4U, 0x3ebbde49bcfc80baU, 0x3f0692583e7cd7a2U,
  0x3e46a369bf9975e5U, 0xbeab72b83da2b58dU, 0x3e7ccea2bf3a99daU, 0xc08da357be2c693aU,
  0xbf3d7a1abdaa31eaU, 0xc07c22d0c037b648U, 0xbf9aec0abfd8166eU, 0x3f530688bdff9254U,
  0x3e3ee6a8bf037a27U, 0x3ee9fa0dbe19b7d3U, 0x3e80b8a9bff02415U, 0x400152313f04a324U,
  0x3f58a68cc049ee5bU, 0x3f7b1647befbb83dU, 0x3f8fa9babeff702cU, 0x3f4c537dbc880753U,
  0xbe817320bf5ff0d3U, 0x3cf192793f112dbeU, 0xbef51288becef4d1U, 0xbf5f8d233f141e28U,
  0xbcc2c2323f607af7U, 0x3f70729c3f8c92baU, 0xbe8a02c43caa6e94U, 0x3f5d23afbe7b7dc2U,
  0x3f9aaa95beb6f0e4U, 0xbf6a28c83f872c50U, 0x3eb702963f94a639U, 0xbf66e2a6be05f4bcU,
  0x3e9c9371bebad07eU, 0x3f6b4b18beb64af9U, 0xbee3602e3fa0ddedU, 0x3f14f8adbf021d99U,
  0x3f19ad233eaf2fbdU, 0xbf4270f2be0c9cd1U, 0xc02b11d3bf9b5763U, 0x3ede3e673fd6ba2fU,
  0x3f73a73dbe840e93U, 0x3fb9cba5bf5aacdfU, 0xbe4c4fef400252edU, 0xbf1a0ee4404f3b71U,
  0xbfbe84313f835091U, 0x3fb44935bee77fdbU, 0x3fedd767c01a7edeU, 0x3ea3f394bef133e0U,
  0x3f7aa80ebfa5a150U, 0x3e83a9dcc01cf7afU, 0xbe41c3cebf3817d0U, 0xbf440e28bdeaebcbU,
  0xbeefe051bf880160U, 0xbf95d5ddbf3ca672U, 0xbe063bf5c080c903U, 0xbdc3e282bd0ba0eeU,
  0xbe42a9b2bf9f3660U, 0xbe2afa3e3f07c802U, 0xc1964e74c034d0fdU, 0xc03d8bb0bfc4bec1U,
  0x3f9831f4c02769e4U, 0xbdb18a41c049343dU, 0xbcc86bf3bccc04d9U, 0xc015fdaa3dfbf36dU,
  0xbec7c520c02df7c4U, 0xbf265a573e94cca8U, 0x3dd12fbdbf45c686U, 0x3fb444af3f08ae60U,
  0xc036f01b3ebcf1ecU,
};


ai_handle g_network_1691831284938_weights_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(s_network_1691831284938_weights_array_u64),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};

